package com.db.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateRelationshipDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

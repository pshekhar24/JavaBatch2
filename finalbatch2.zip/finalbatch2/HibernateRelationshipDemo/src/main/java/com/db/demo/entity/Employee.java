package com.db.demo.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1324234L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empId;
	
	private String empName;
	
	private int empAge;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "addressId")
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	private Address address;
	
	@ManyToOne
	@JoinColumn(name = "roleId")
	@JsonManagedReference
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	private Role role;
	
	@ManyToMany
	@JoinTable(name = "Employee_Project", joinColumns = { @JoinColumn(name = "employeeId") }, inverseJoinColumns = {
			@JoinColumn(name = "projectId") })
	private Set<Project> projects;
}

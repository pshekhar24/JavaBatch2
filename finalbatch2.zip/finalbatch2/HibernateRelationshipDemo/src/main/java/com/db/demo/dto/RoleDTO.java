package com.db.demo.dto;

import java.util.Set;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class RoleDTO {

	private int roleId;
	private String roleName;
	private Set<EmployeeDTO> employees;
	
}

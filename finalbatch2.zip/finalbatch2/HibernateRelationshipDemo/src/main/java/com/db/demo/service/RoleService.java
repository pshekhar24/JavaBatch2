package com.db.demo.service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.db.demo.dto.EmployeeDTO;
import com.db.demo.dto.RoleDTO;
import com.db.demo.entity.Employee;
import com.db.demo.entity.Role;
import com.db.demo.repository.RoleRepository;

@Service
public class RoleService {
	
	@Autowired
	private RoleRepository roleRepository;
	
	public RoleDTO getRoleById(int id) {
		RoleDTO roleDTO = new RoleDTO();
		
		Optional<Role> roleOptional =  roleRepository.findById(id);
		if (!roleOptional.isEmpty()) {
			Role role = roleOptional.get();
			
			roleDTO.setRoleId(role.getRoleId());
			roleDTO.setRoleName(role.getRoleName());
			
			Set<Employee> employees = role.getEmployees();
			Set<EmployeeDTO> employeeDTOs = new HashSet<>();
			if (employees != null) {
				for (Employee employee : employees) {
					EmployeeDTO employeeDTO = new EmployeeDTO();
					employeeDTO.setEmpId(employee.getEmpId());
					employeeDTO.setAge(employee.getEmpAge());
					employeeDTO.setEmpName(employee.getEmpName());
					employeeDTOs.add(employeeDTO);
				}
			}
			roleDTO.setEmployees(employeeDTOs);
		}
		return roleDTO;
	}

}

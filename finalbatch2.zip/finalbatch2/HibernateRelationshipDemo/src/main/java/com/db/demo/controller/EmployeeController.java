package com.db.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.db.demo.dto.EmployeeDTO;
import com.db.demo.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {

	Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@Autowired
	private EmployeeService employeeService;

	@CrossOrigin
	@GetMapping(path = "/{id}")
	public EmployeeDTO getEmployeeById(@PathVariable("id") Integer id) {
		logger.trace("###A TRACE Message");
        logger.debug("###A DEBUG Message");
        logger.info("###An INFO Message");
        logger.warn("###A WARN Message");
        logger.error("###An ERROR Message");
		return employeeService.fetchEmployeeById(id);
	}
	

}

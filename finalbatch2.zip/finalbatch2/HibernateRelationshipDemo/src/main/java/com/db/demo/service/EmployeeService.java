package com.db.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.db.demo.dto.EmployeeDTO;
import com.db.demo.entity.Employee;
import com.db.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;

	public EmployeeDTO fetchEmployeeById(int id) {
		Employee employee = null;
		EmployeeDTO employeeDTO = null;
		try {
			Optional<Employee> empOptional = employeeRepository.findById(id);
			employee = empOptional.get();
			// transform from emtity to DTO
			employeeDTO = new EmployeeDTO();
			employeeDTO.setAge(employee.getEmpAge());
			employeeDTO.setEmpName(employee.getEmpName());
			employeeDTO.setEmpId(employee.getEmpId());
			employeeDTO.setAddress(employee.getAddress());
			employeeDTO.setRole(employee.getRole());

		} catch (Exception e) {
			System.out.println(e);
		}
		return employeeDTO;
	}
	
}

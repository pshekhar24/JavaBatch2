package com.db.demo.dto;

import java.awt.Robot;

import com.db.demo.entity.Address;
import com.db.demo.entity.Role;

import lombok.Data;

@Data
public class EmployeeDTO {
	
	private int empId;
	private String empName;
	private int age;
	private Address address;
	private Role role;
	
}

function alertMe() {
    var message = document.getElementById("alertMe").value;
    alert(message);
    addNumber(5, 6);
}

function addNumber(a, b) {
    alert(a + b);
}